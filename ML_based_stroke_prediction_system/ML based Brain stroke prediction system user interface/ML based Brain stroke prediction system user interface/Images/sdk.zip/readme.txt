The following packages are included in this download:
   https://api.nuget.org/v3-flatcontainer/microsoft.crmsdk.xrmtooling.pluginregistrationtool/9.1.0.184/microsoft.crmsdk.xrmtooling.pluginregistrationtool.9.1.0.184.nupkg
   https://api.nuget.org/v3-flatcontainer/microsoft.crmsdk.coretools/9.1.0.115/microsoft.crmsdk.coretools.9.1.0.115.nupkg
   https://api.nuget.org/v3-flatcontainer/microsoft.crmsdk.xrmtooling.packagedeployment.wpf/9.1.0.129/microsoft.crmsdk.xrmtooling.packagedeployment.wpf.9.1.0.129.nupkg
   https://api.nuget.org/v3-flatcontainer/microsoft.crmsdk.xrmtooling.configurationmigration.wpf/9.1.0.110/microsoft.crmsdk.xrmtooling.configurationmigration.wpf.9.1.0.110.nupkg

